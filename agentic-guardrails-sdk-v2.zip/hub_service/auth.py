
import os
from fastapi import HTTPException, Header

def require_pat(authorization: str = Header(None)):
    pats = [p.strip() for p in os.getenv("HUB_PATS", "").split(",") if p.strip()]
    if not pats:
        return
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Missing bearer token")
    token = authorization.split(" ", 1)[1].strip()
    if token not in pats:
        raise HTTPException(status_code=403, detail="Invalid token")

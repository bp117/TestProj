
from pydantic import BaseModel, Field, HttpUrl
from typing import Optional, List, Dict, Any
from datetime import datetime

class GuardrailUpsert(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    version: str = Field(..., min_length=1)
    description: Optional[str] = None
    tags: List[str] = []
    maintainers: List[str] = []
    repo_url: Optional[HttpUrl] = None
    schema: Optional[Dict[str, Any]] = None
    metadata: Dict[str, Any] = {}

class GuardrailOut(GuardrailUpsert):
    id: str
    created_at: datetime
    updated_at: datetime
    status: str = "registered"

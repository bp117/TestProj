
import json, asyncio
from guardrails_sdk import GuardrailEngine, AgentConfig, ConsoleSink, StaticHeuristicJudge
from guardrails_sdk.adapters import trace_from_arize_like_spans

AGENT_SCHEMA = "agent-schema.json"
TRACE_JSON   = "trace.json"

async def main():
    cfg = AgentConfig.from_file(AGENT_SCHEMA)
    judge = StaticHeuristicJudge(allowed_tools={"search_and_summarize"})
    engine = GuardrailEngine(cfg=cfg, judge=judge, sinks=[ConsoleSink()])
    spans = json.loads(open(TRACE_JSON, "r").read())
    trace = trace_from_arize_like_spans(spans)
    report = await engine.evaluate_trace(trace=trace, context={
        "reference_outputs": "User's Question: To calculate the value of an expression \nTrajectory:{'1':'calculate'}"
    })
    print("\nOVERALL:", report.overall_passed)

if __name__ == "__main__":
    asyncio.run(main())

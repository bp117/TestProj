
from __future__ import annotations
from typing import Dict, Type, Optional, Callable
import os, asyncio

class GuardrailRegistry:
    _registry: Dict[str, Type] = {}

    @classmethod
    def register(cls, name: str, guardrail_cls: Type) -> None:
        cls._registry[name] = guardrail_cls

    @classmethod
    def get(cls, name: str) -> Optional[Type]:
        return cls._registry.get(name)

    @classmethod
    def all(cls) -> Dict[str, Type]:
        return dict(cls._registry)

async def _maybe_publish_to_internal_hub(metadata: dict) -> None:
    if os.getenv("INTERNAL_GUARDRAILS_HUB_ENABLED", "false").lower() != "true":
        return
    url = os.getenv("INTERNAL_GUARDRAILS_HUB_URL")
    if not url: return
    headers = {"Content-Type": "application/json"}
    token = os.getenv("INTERNAL_GUARDRAILS_HUB_TOKEN")
    if token: headers["Authorization"] = f"Bearer {token}"
    try:
        import httpx
        async with httpx.AsyncClient(timeout=5.0, verify=True) as client:
            await client.post(url, json=metadata, headers=headers)
    except Exception:
        pass

def guardrail(name: str, version: str = "0.1", description: str = "") -> Callable[[Type], Type]:
    def _decorator(cls: Type) -> Type:
        GuardrailRegistry.register(name, cls)
        metadata = {
            "name": name,
            "version": version,
            "description": description or getattr(cls, "__doc__", "") or "",
            "schema": getattr(cls, "CONFIG_SCHEMA", None),
        }
        try:
            asyncio.create_task(_maybe_publish_to_internal_hub(metadata))
        except RuntimeError:
            pass
        return cls
    return _decorator

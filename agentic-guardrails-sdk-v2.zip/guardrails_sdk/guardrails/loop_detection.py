
from __future__ import annotations
from typing import Dict, Any, List
from collections import Counter
from .base import BaseGuardrail
from ..models import GuardrailResult, Violation, Trace, EventKind
from ..config import AgentConfig, LoopGoal

class LoopDetectionGuardrail(BaseGuardrail):
    def __init__(self, name: str, cfg: AgentConfig):
        super().__init__(name); self.cfg = cfg

    async def evaluate(self, *, trace: Trace, goal_name: str, context: Dict[str, Any]) -> GuardrailResult:
        lg: LoopGoal | None = self.cfg.loop_for(goal_name)
        violations: List[Violation] = []; metrics: Dict[str, Any] = {}
        if not self.cfg.loop_detection.enabled or lg is None:
            return GuardrailResult(self.name, goal_name, True, "info", violations, metrics)

        tool_seq = [e.name for e in trace.events if e.kind == EventKind.TOOL and e.name]
        tool_counts = Counter(tool_seq)
        metrics["tool_counts"] = dict(tool_counts)
        for tool, cnt in tool_counts.items():
            if cnt >= lg.threshold:
                violations.append(Violation("LOOP.REPEAT", f"Tool '{tool}' executed {cnt} times >= threshold {lg.threshold}"))

        cycles = 0; prev = None
        for e in trace.events:
            if prev and prev != e.kind and e.kind in (EventKind.LLM, EventKind.TOOL):
                cycles += 1
            prev = e.kind
        metrics["alternating_cycles"] = cycles
        passed = len(violations) == 0
        return GuardrailResult(self.name, goal_name, passed, "fail" if not passed else "info", violations, metrics)

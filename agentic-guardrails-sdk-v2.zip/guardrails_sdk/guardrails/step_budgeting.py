
from __future__ import annotations
from typing import Dict, Any, List
from .base import BaseGuardrail
from ..models import GuardrailResult, Violation, Trace
from ..config import AgentConfig, BudgetGoal

class StepBudgetingGuardrail(BaseGuardrail):
    def __init__(self, name: str, cfg: AgentConfig):
        super().__init__(name); self.cfg = cfg

    async def evaluate(self, *, trace: Trace, goal_name: str, context: Dict[str, Any]) -> GuardrailResult:
        b: BudgetGoal | None = self.cfg.budget_for(goal_name)
        violations: List[Violation] = []
        metrics: Dict[str, Any] = {"steps": trace.steps(), "tokens_total": trace.total_tokens(), "duration_sec": round(trace.duration_seconds(), 3)}
        if not self.cfg.budgeting.enabled or b is None:
            return GuardrailResult(self.name, goal_name, True, "info", violations, metrics)
        if b.max_steps is not None and trace.steps() > b.max_steps:
            violations.append(Violation("BUDGET.STEPS", f"Steps {trace.steps()} > max {b.max_steps}"))
        if b.max_token_limit is not None and trace.total_tokens() > b.max_token_limit:
            violations.append(Violation("BUDGET.TOKENS", f"Tokens {trace.total_tokens()} > max {b.max_token_limit}"))
        if b.max_duration_seconds is not None and trace.duration_seconds() > b.max_duration_seconds:
            violations.append(Violation("BUDGET.DURATION", f"Duration {trace.duration_seconds():.2f}s > max {b.max_duration_seconds}s"))
        passed = len(violations) == 0
        return GuardrailResult(self.name, goal_name, passed, "fail" if not passed else "info", violations, metrics)


from __future__ import annotations
import re
from typing import Dict, Any, List, Set
from .base import BaseGuardrail
from ..models import GuardrailResult, Violation, Trace, EventKind
from ..config import AgentConfig, GoalDriftGoal
from ..judge import LLMJudge
from ..prompts import TRAJECTORY_ACCURACY_PROMPT_WITH_REFERENCE
from ..phoenix_compat import llm_classify_one

def _actual_trajectory_kv(trace: Trace) -> list[dict]:
    """Return a Phoenix-like ordered list of step->tool mapping: [{"1": "tool"}, ...]."""
    steps: list[dict] = []
    idx = 1
    for e in trace.events:
        if e.kind == EventKind.TOOL and (e.name or e.tool_name):
            steps.append({str(idx): (e.name or e.tool_name)})
            idx += 1
    return steps

def _user_input(trace: Trace) -> str:
    for e in trace.events:
        if e.kind == EventKind.LLM and e.input_value:
            return str(e.input_value)
    return ""

def _tools_def_summary(trace: Trace) -> str:
    uniq: list[str] = []
    for t in trace.used_tools():
        if t and t not in uniq:
            uniq.append(t)
    return ", ".join(uniq) or "(none)"

def _build_plan_from_trace(trace: Trace) -> str:
    lines: List[str] = []
    for e in trace.events:
        if e.kind == EventKind.LLM and e.tool_name:
            lines.append(f"- LLM called tool: {e.tool_name}")
        elif e.kind == EventKind.TOOL:
            lines.append(f"- TOOL executed: {e.name}")
    return "\n".join(lines) if lines else "- (no plan extracted)"

def _tools_def_from_config(cfg: AgentConfig, goal: GoalDriftGoal) -> str:
    return f"- Expected primary tool: {goal.trajectory.tool_name}\n- Expected params: {', '.join(goal.trajectory.expected_params.keys()) or '(none)'}"

class GoalDriftGuardrail(BaseGuardrail):
    """Goal Drift = Trajectory Accuracy + Tool Selection.

    *Trajectory* is judged via an LLM (Arize-style prompt with golden references when provided).
    *Tool Selection* validates expected tool and parameter constraints, and applies allow/deny policy for this goal if configured.
    """
    def __init__(self, name: str, cfg: AgentConfig, judge: LLMJudge):
        super().__init__(name)
        self.cfg = cfg
        self.judge = judge

    async def evaluate(self, *, trace: Trace, goal_name: str, context: Dict[str, Any]) -> GuardrailResult:
        gd_goal: GoalDriftGoal | None = self.cfg.goal_drift_for(goal_name)
        violations: List[Violation] = []
        metrics: Dict[str, Any] = {}

        if not self.cfg.goal_drift.enabled or gd_goal is None:
            return GuardrailResult(self.name, goal_name, True, "info", violations, metrics)

        # ---------------- Tool Selection checks ----------------
        expected_tool = gd_goal.trajectory.tool_name
        used_tools = trace.used_tools()
        if expected_tool and expected_tool not in used_tools:
            violations.append(Violation("GD.MISSING_TOOL", f"Expected tool '{expected_tool}' not used",
                                        [e.span_id for e in trace.events if e.kind in (EventKind.LLM, EventKind.TOOL)]))

        # Validate required/enum/pattern params for the expected tool
        for e in trace.events:
            if (e.kind == EventKind.TOOL and (e.name == expected_tool or e.tool_name == expected_tool)) and e.tool_args:
                for p_name, rule in gd_goal.trajectory.expected_params.items():
                    if rule.required and p_name not in e.tool_args:
                        violations.append(Violation("GD.MISSING_PARAM", f"Missing required param '{p_name}'", [e.span_id]))
                    if rule.enum and p_name in e.tool_args and e.tool_args[p_name] not in set(rule.enum):
                        violations.append(Violation("GD.BAD_ENUM", f"Param '{p_name}' not in {rule.enum}", [e.span_id]))
                    if rule.pattern and p_name in e.tool_args and not re.search(rule.pattern, str(e.tool_args[p_name])):
                        violations.append(Violation("GD.BAD_PATTERN", f"Param '{p_name}' fails pattern {rule.pattern}", [e.span_id]))

        # Allow/Deny policy per goal if SafeTools config exists for this goal
        st = self.cfg.safe_tools_for(goal_name)
        if st:
            allow: Set[str] = set(st.allow or [])
            deny: Set[str] = set(st.deny or [])
            for t in used_tools:
                if t in deny:
                    violations.append(Violation("GD.TOOL.DENY", f"Tool '{t}' is denied"))
            if allow:
                for t in used_tools:
                    if t not in allow:
                        violations.append(Violation("GD.TOOL.NOT_ALLOWED", f"Tool '{t}' not in allowed list"))

        # ---------------- Trajectory Accuracy (Arize-style) ----------------
        reference_outputs = context.get("reference_outputs")
        if reference_outputs:
            variables = {
                "reference_outputs": reference_outputs,
                "tool_calls": _actual_trajectory_kv(trace),
                "attributes.input.value": _user_input(trace),
                "attributes.llm.tools": _tools_def_summary(trace),
            }
            try:
                label_ci = await llm_classify_one(
                    template=TRAJECTORY_ACCURACY_PROMPT_WITH_REFERENCE,
                    variables=variables,
                    rails=["correct", "incorrect"],
                )
                metrics["arize_style_label"] = label_ci
                if label_ci == "incorrect":
                    violations.append(Violation("GD.TRAJECTORY_INCORRECT",
                                                "Arize-style judge: trajectory deemed incorrect", []))
            except Exception as ex:
                metrics["arize_style_error"] = str(ex)

        # ---------------- Secondary plan judge (ideal/valid/invalid) ----------------
        task = context.get("task") or "Execute the user request using available tools."
        plan = _build_plan_from_trace(trace)
        tools_def = _tools_def_from_config(self.cfg, gd_goal)
        label = await self.judge.classify_plan(task, tools_def, plan)
        metrics["judge_label"] = label
        if label == "invalid":
            violations.append(Violation("GD.JUDGE_INVALID", "LLM Judge marked the plan INVALID", []))

        passed = (len(violations) == 0) and (label in ("ideal", "valid"))
        severity = "fail" if not passed else "info"
        return GuardrailResult(self.name, goal_name, passed, severity, violations, metrics)

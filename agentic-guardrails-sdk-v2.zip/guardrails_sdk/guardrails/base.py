
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict
from ..models import Trace, GuardrailResult

class BaseGuardrail(ABC):
    def __init__(self, name: str):
        self.name = name

    @abstractmethod
    async def evaluate(self, *, trace: Trace, goal_name: str, context: Dict[str, Any]) -> GuardrailResult: ...

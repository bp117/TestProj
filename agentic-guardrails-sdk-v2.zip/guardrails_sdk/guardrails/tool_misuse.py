
from __future__ import annotations
from typing import Dict, Any, List, Set
from .base import BaseGuardrail
from ..models import GuardrailResult, Violation, Trace
from ..config import AgentConfig, SafeToolsGoal

class ToolMisuseGuardrail(BaseGuardrail):
    def __init__(self, name: str, cfg: AgentConfig):
        super().__init__(name); self.cfg = cfg

    async def evaluate(self, *, trace: Trace, goal_name: str, context: Dict[str, Any]) -> GuardrailResult:
        st: SafeToolsGoal | None = self.cfg.safe_tools_for(goal_name)
        violations: List[Violation] = []; metrics: Dict[str, Any] = {}
        if not self.cfg.safe_tools.enabled or st is None:
            return GuardrailResult(self.name, goal_name, True, "info", violations, metrics)
        used = trace.used_tools()
        allow: Set[str] = set(st.allow or [])
        deny: Set[str] = set(st.deny or [])
        for t in used:
            if t in deny:
                violations.append(Violation("TOOL.DENY", f"Tool '{t}' is denied"))
        if allow:
            for t in used:
                if t not in allow:
                    violations.append(Violation("TOOL.NOT_ALLOWED", f"Tool '{t}' not in allowed list"))
        passed = len(violations) == 0
        return GuardrailResult(self.name, goal_name, passed, "fail" if not passed else "info", violations, metrics)

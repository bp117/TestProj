
# Guardrails Hub — React + TypeScript + Radix + Tailwind (Vite)

A sleek catalog UI for your internal Guardrails Hub.

## Quick start
```bash
pnpm i   # or: npm i / yarn
cp .env.local.example .env.local
# edit VITE_HUB_BASE and VITE_HUB_PAT as needed
pnpm dev # or: npm run dev
```
Open http://localhost:5173

## Features
- List latest version of each guardrail (name, version, description, tags, status)
- Search, tag filter, status filter
- View details in a right-side drawer (maintainers, repo link, schema JSON, install snippet)
- Register a new guardrail (Dialog form)
- Promote status: registered ↔ approved ↔ deprecated
- Radix UI primitives + Tailwind glassmorphism styles

## Env
- `VITE_HUB_BASE` — base URL of your hub (e.g., http://localhost:8080)
- `VITE_HUB_PAT` — optional bearer token to call hub APIs

## Notes
- This UI expects the FastAPI hub from the SDK bundle (same endpoints).
- Tailor colors in `tailwind.config.cjs`. 
- Feel free to swap the card style for your bank’s design system.

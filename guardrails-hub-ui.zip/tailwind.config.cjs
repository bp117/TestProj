
/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "#0b0f17",
        card: "#111827",
        accent: "#7c3aed"
      }
    },
  },
  plugins: [],
};


import * as Select from '@radix-ui/react-select'
import { ChevronDown, Tag, Search } from 'lucide-react'
import { useState } from 'react'

type Props = {
  tag: string
  onTagChange: (t: string)=>void
  search: string
  onSearch: (s: string)=>void
  statuses: Array<'registered'|'approved'|'deprecated'>
  activeStatuses: Set<string>
  onToggleStatus: (s: string)=>void
}

export default function Filters({ tag, onTagChange, search, onSearch, statuses, activeStatuses, onToggleStatus }: Props) {
  const [tagInput, setTagInput] = useState(tag)
  return (
    <div className="card card-hover p-3 flex flex-col md:flex-row md:items-center gap-3">
      <div className="flex-1 flex items-center gap-2">
        <div className="relative flex-1">
          <input
            placeholder="Search by name or description..."
            value={search}
            onChange={(e)=>onSearch(e.target.value)}
            className="input w-full pl-9"
          />
          <Search className="h-4 w-4 absolute left-2 top-2.5 text-white/50" />
        </div>
        <div className="relative">
          <input
            placeholder="Tag filter (press Enter)"
            value={tagInput}
            onChange={(e)=>setTagInput(e.target.value)}
            onKeyDown={(e)=>{ if(e.key==='Enter'){ onTagChange(tagInput.trim()); } }}
            className="input w-56 pl-8"
          />
          <Tag className="h-4 w-4 absolute left-2 top-2.5 text-white/50" />
        </div>
      </div>
      <div className="flex items-center gap-2">
        {statuses.map(s => (
          <button
            key={s}
            onClick={()=>onToggleStatus(s)}
            className={`badge ${activeStatuses.has(s) ? 'badge-green' : 'badge-gray'}`}
            title="Toggle status filter"
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  )
}


import { Sparkles, ServerCog } from 'lucide-react'

export default function Header() {
  return (
    <header className="sticky top-0 z-20 bg-bg/80 backdrop-blur border-b border-white/10">
      <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-accent/20 flex items-center justify-center">
            <Sparkles className="h-5 w-5 text-accent" />
          </div>
          <div>
            <h1 className="text-lg font-semibold">Guardrails Hub</h1>
            <p className="text-xs text-white/60">Discover · Register · Promote</p>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-3 text-xs text-white/60">
          <ServerCog className="h-4 w-4" />
          <span>Radix · Tailwind · Vite</span>
        </div>
      </div>
    </header>
  )
}

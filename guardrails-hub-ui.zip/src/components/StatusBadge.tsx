
type Props = { status: 'registered'|'approved'|'deprecated' }
export default function StatusBadge({ status }: Props) {
  const cls = status === 'approved' ? 'badge badge-green' : status === 'registered' ? 'badge badge-gray' : 'badge badge-amber'
  return <span className={cls}>{status}</span>
}

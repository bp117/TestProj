
import * as Dialog from '@radix-ui/react-dialog'
import { X, ExternalLink, Copy } from 'lucide-react'
import type { GuardrailDetail } from '../types'
import { useMemo } from 'react'

type Props = {
  open: boolean
  onOpenChange: (o:boolean)=>void
  data?: GuardrailDetail | null
}

export default function DetailDrawer({ open, onOpenChange, data }: Props) {
  const json = useMemo(()=> JSON.stringify(data?.schema ?? {}, null, 2), [data])
  const copyInstall = async () => {
    const snippet = `from guardrails_sdk.registry import guardrail\n\n@guardrail(\"${data?.name}\", version=\"${data?.version}\")\nclass MyRail: ...`
    await navigator.clipboard.writeText(snippet)
  }

  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/60" />
        <Dialog.Content className="fixed top-0 right-0 h-full w-full sm:w-[560px] card border-l border-white/10 p-4 overflow-auto">
          <div className="flex items-start justify-between">
            <div>
              <Dialog.Title className="text-xl font-semibold">{data?.name}</Dialog.Title>
              <Dialog.Description className="text-xs text-white/60">v{data?.version}</Dialog.Description>
            </div>
            <Dialog.Close asChild>
              <button className="btn" aria-label="close"><X className="h-4 w-4"/></button>
            </Dialog.Close>
          </div>

          <div className="mt-4 space-y-4">
            <section className="card p-3">
              <h4 className="font-semibold mb-2">About</h4>
              <p className="text-sm text-white/80 whitespace-pre-wrap">{data?.description || '—'}</p>
            </section>

            <section className="card p-3">
              <h4 className="font-semibold mb-2">Metadata</h4>
              <div className="text-sm flex flex-col gap-2">
                <div><span className="text-white/60">Maintainers:</span> {data?.maintainers?.join(', ') || '—'}</div>
                <div><span className="text-white/60">Tags:</span> {data?.tags?.join(', ') || '—'}</div>
                <div><span className="text-white/60">Repo:</span> {data?.repo_url ? <a className="text-accent underline inline-flex items-center gap-1" href={data.repo_url} target="_blank" rel="noreferrer">open <ExternalLink className="h-3 w-3"/></a> : '—'}</div>
              </div>
            </section>

            <section className="card p-3">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Install Snippet</h4>
                <button className="btn" onClick={copyInstall}><Copy className="h-4 w-4"/>Copy</button>
              </div>
              <pre className="mt-2 bg-black/40 p-3 rounded-xl text-xs overflow-auto"><code>
from guardrails_sdk.registry import guardrail

@guardrail("{data?.name}", version="{data?.version}")
class MyRail:
    async def evaluate(self, *, trace, goal_name, context):
        ...
              </code></pre>
            </section>

            <section className="card p-3">
              <h4 className="font-semibold mb-2">Schema</h4>
              <pre className="bg-black/40 p-3 rounded-xl text-xs overflow-auto">{json}</pre>
            </section>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}

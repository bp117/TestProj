
import * as DropdownMenu from '@radix-ui/react-dropdown-menu'
import { MoreHorizontal, Clipboard, GitBranch } from 'lucide-react'
import StatusBadge from './StatusBadge'
import type { Guardrail } from '../types'

type Props = {
  item: Guardrail
  onOpen: (name: string, version: string)=>void
  onPromote: (name: string, version: string, status: 'registered'|'approved'|'deprecated')=>void
}

export default function GuardrailCard({ item, onOpen, onPromote }: Props) {
  const copySnippet = async () => {
    const snippet = `from guardrails_sdk.registry import guardrail\n\n@guardrail(\"${item.name}\", version=\"${item.version}\")\nclass MyRail: ...`
    await navigator.clipboard.writeText(snippet)
  }

  return (
    <div className="card card-hover p-4 flex flex-col gap-3">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h3 className="text-base font-semibold">{item.name}</h3>
          <p className="text-xs text-white/60">v{item.version}</p>
        </div>
        <DropdownMenu.Root>
          <DropdownMenu.Trigger asChild>
            <button className="btn" aria-label="actions"><MoreHorizontal className="h-4 w-4"/></button>
          </DropdownMenu.Trigger>
          <DropdownMenu.Content className="card p-1 min-w-[200px]">
            <DropdownMenu.Item className="px-2 py-2 hover:bg-white/10 rounded-lg flex items-center gap-2" onClick={copySnippet}>
              <Clipboard className="h-4 w-4"/> Copy install snippet
            </DropdownMenu.Item>
            <DropdownMenu.Separator className="h-px bg-white/10 my-1"/>
            <div className="px-2 py-1 text-xs text-white/50">Promote status</div>
            <DropdownMenu.Item className="px-2 py-2 hover:bg-white/10 rounded-lg" onClick={()=>onPromote(item.name, item.version, 'approved')}>
              ✅ Approve
            </DropdownMenu.Item>
            <DropdownMenu.Item className="px-2 py-2 hover:bg-white/10 rounded-lg" onClick={()=>onPromote(item.name, item.version, 'registered')}>
              ↩️ Revert to registered
            </DropdownMenu.Item>
            <DropdownMenu.Item className="px-2 py-2 hover:bg-white/10 rounded-lg" onClick={()=>onPromote(item.name, item.version, 'deprecated')}>
              ⚠️ Deprecate
            </DropdownMenu.Item>
          </DropdownMenu.Content>
        </DropdownMenu.Root>
      </div>
      <p className="text-sm text-white/80 line-clamp-3">{item.description || '—'}</p>
      <div className="flex items-center justify-between">
        <div className="flex gap-1 flex-wrap">
          {item.tags?.slice(0,4).map((t)=>(<span key={t} className="badge badge-gray">{t}</span>))}
        </div>
        <StatusBadge status={item.status} />
      </div>
      <div className="flex items-center justify-between pt-1">
        <button className="btn btn-primary" onClick={()=>onOpen(item.name, item.version)}>View details</button>
      </div>
    </div>
  )
}

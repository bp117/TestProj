
import * as Dialog from '@radix-ui/react-dialog'
import { useState } from 'react'
import { Plus, X } from 'lucide-react'
import type { UpsertPayload } from '../types'

type Props = {
  onSubmit: (payload: UpsertPayload)=>Promise<void>
}

export default function RegisterDialog({ onSubmit }: Props) {
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState<UpsertPayload>({
    name: '', version: '', description: '',
    tags: [], maintainers: [], repo_url: '', schema: {}, metadata: {}
  })
  const [tagInput, setTagInput] = useState('')
  const [maintInput, setMaintInput] = useState('')
  const [jsonErr, setJsonErr] = useState<string | null>(null)
  const [schemaText, setSchemaText] = useState('{}')

  const addTag = () => {
    const t = tagInput.trim()
    if (!t) return
    setForm(prev => ({...prev, tags: [...(prev.tags||[]), t]}))
    setTagInput('')
  }
  const addMaint = () => {
    const m = maintInput.trim()
    if (!m) return
    setForm(prev => ({...prev, maintainers: [...(prev.maintainers||[]), m]}))
    setMaintInput('')
  }

  const submit = async () => {
    try {
      const parsed = schemaText.trim() ? JSON.parse(schemaText) : {}
      setJsonErr(null)
      await onSubmit({...form, schema: parsed})
      setOpen(false)
      setForm({ name:'', version:'', description:'', tags:[], maintainers:[], repo_url:'', schema:{}, metadata:{} })
      setSchemaText('{}')
    } catch (e:any) {
      setJsonErr(e.message || 'Invalid JSON')
    }
  }

  return (
    <Dialog.Root open={open} onOpenChange={setOpen}>
      <Dialog.Trigger asChild>
        <button className="btn btn-primary"><Plus className="h-4 w-4"/>Register Guardrail</button>
      </Dialog.Trigger>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50" />
        <Dialog.Content className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[95vw] max-w-3xl max-h-[90vh] overflow-auto card p-4">
          <div className="flex items-center justify-between mb-2">
            <Dialog.Title className="text-lg font-semibold">Register Guardrail</Dialog.Title>
            <Dialog.Close asChild><button className="btn"><X className="h-4 w-4"/></button></Dialog.Close>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-2">
              <label className="text-xs text-white/60">Name</label>
              <input className="input w-full" value={form.name} onChange={(e)=>setForm({...form, name:e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-white/60">Version</label>
              <input className="input w-full" value={form.version} onChange={(e)=>setForm({...form, version:e.target.value})} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs text-white/60">Description</label>
              <textarea rows={3} className="input w-full" value={form.description} onChange={(e)=>setForm({...form, description:e.target.value})} />
            </div>
            <div className="space-y-2">
              <label className="text-xs text-white/60">Add Tag</label>
              <div className="flex gap-2">
                <input className="input w-full" value={tagInput} onChange={(e)=>setTagInput(e.target.value)} onKeyDown={(e)=> e.key==='Enter' && addTag()} />
                <button className="btn" onClick={addTag}>Add</button>
              </div>
              <div className="flex flex-wrap gap-1 mt-1">
                {form.tags?.map((t,i)=>(<span key={i} className="badge badge-gray">{t}</span>))}
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs text-white/60">Add Maintainer (email or id)</label>
              <div className="flex gap-2">
                <input className="input w-full" value={maintInput} onChange={(e)=>setMaintInput(e.target.value)} onKeyDown={(e)=> e.key==='Enter' && addMaint()} />
                <button className="btn" onClick={addMaint}>Add</button>
              </div>
              <div className="flex flex-wrap gap-1 mt-1">
                {form.maintainers?.map((m,i)=>(<span key={i} className="badge badge-gray">{m}</span>))}
              </div>
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs text-white/60">Repo URL</label>
              <input className="input w-full" value={form.repo_url} onChange={(e)=>setForm({...form, repo_url:e.target.value})} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <label className="text-xs text-white/60">Schema (JSON)</label>
              <textarea rows={10} className="input w-full font-mono text-xs" value={schemaText} onChange={(e)=>setSchemaText(e.target.value)} />
              {jsonErr && <div className="text-amber-300 text-xs">{jsonErr}</div>}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-3">
            <Dialog.Close asChild><button className="btn">Cancel</button></Dialog.Close>
            <button className="btn btn-primary" onClick={submit}>Submit</button>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  )
}


export type Guardrail = {
  id: string
  name: string
  version: string
  description?: string
  tags: string[]
  status: 'registered' | 'approved' | 'deprecated'
  updated_at?: string
}

export type GuardrailDetail = {
  id: string
  name: string
  version: string
  description?: string
  tags: string[]
  maintainers: string[]
  repo_url?: string
  schema?: Record<string, any> | null
  metadata?: Record<string, any>
  status: 'registered' | 'approved' | 'deprecated'
  created_at?: string
  updated_at?: string
}

export type UpsertPayload = {
  name: string
  version: string
  description?: string
  tags?: string[]
  maintainers?: string[]
  repo_url?: string
  schema?: Record<string, any> | null
  metadata?: Record<string, any>
}


import type { Guardrail, GuardrailDetail, UpsertPayload } from './types'

const BASE = import.meta.env.VITE_HUB_BASE || 'http://localhost:8080'
const PAT  = import.meta.env.VITE_HUB_PAT || ''

function headers(json=true) {
  const h: Record<string, string> = {}
  if (PAT) h['Authorization'] = `Bearer ${PAT}`
  if (json) h['Content-Type'] = 'application/json'
  return h
}

export async function listLatest(tag?: string): Promise<Guardrail[]> {
  const url = new URL('/api/guardrails', BASE)
  if (tag) url.searchParams.set('tag', tag)
  const res = await fetch(url, { headers: headers(false) })
  if (!res.ok) throw new Error(`List failed: ${res.status}`)
  return await res.json()
}

export async function getGuardrail(name: string, version: string): Promise<GuardrailDetail> {
  const url = new URL(`/api/guardrails/${encodeURIComponent(name)}/${encodeURIComponent(version)}`, BASE)
  const res = await fetch(url, { headers: headers(false) })
  if (!res.ok) throw new Error(`Fetch failed: ${res.status}`)
  return await res.json()
}

export async function upsertGuardrail(payload: UpsertPayload): Promise<GuardrailDetail> {
  const url = new URL('/api/guardrails', BASE)
  const res = await fetch(url, { method: 'POST', headers: headers(true), body: JSON.stringify(payload) })
  if (!res.ok) throw new Error(`Upsert failed: ${res.status}`)
  return await res.json()
}

export async function setStatus(name: string, version: string, status: 'registered'|'approved'|'deprecated') {
  const url = new URL(`/api/guardrails/${encodeURIComponent(name)}/${encodeURIComponent(version)}/status`, BASE)
  const params = new URLSearchParams({ status })
  const res = await fetch(`${url}?${params.toString()}`, { method: 'POST', headers: headers(false) })
  if (!res.ok) throw new Error(`Status update failed: ${res.status}`)
  return await res.json()
}

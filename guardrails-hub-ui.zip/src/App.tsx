
import { useEffect, useMemo, useState } from 'react'
import Header from './components/Header'
import Filters from './components/Filters'
import GuardrailCard from './components/GuardrailCard'
import DetailDrawer from './components/DetailDrawer'
import RegisterDialog from './components/RegisterDialog'
import { listLatest, getGuardrail, setStatus, upsertGuardrail } from './api'
import type { Guardrail, GuardrailDetail, UpsertPayload } from './types'

export default function App() {
  const [items, setItems] = useState<Guardrail[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const [search, setSearch] = useState('')
  const [tag, setTag] = useState('')
  const [statusFilters, setStatusFilters] = useState<Set<string>>(new Set(['registered','approved','deprecated']))

  const [open, setOpen] = useState(false)
  const [active, setActive] = useState<GuardrailDetail | null>(null)

  async function refresh() {
    try {
      setLoading(true); setError(null)
      const data = await listLatest(tag || undefined)
      setItems(data)
    } catch (e:any) {
      setError(e.message || 'Failed to load')
    } finally {
      setLoading(false)
    }
  }

  useEffect(()=>{ refresh() }, [tag])

  const filtered = useMemo(()=>{
    return items.filter(i => {
      if (!statusFilters.has(i.status)) return false
      const q = search.trim().toLowerCase()
      if (!q) return true
      return i.name.toLowerCase().includes(q) || (i.description||'').toLowerCase().includes(q)
    })
  }, [items, search, statusFilters])

  const openDetail = async (name: string, version: string) => {
    try {
      const data = await getGuardrail(name, version)
      setActive(data); setOpen(true)
    } catch (e:any) {
      alert(e.message || 'Failed to fetch details')
    }
  }

  const promote = async (name: string, version: string, status: 'registered'|'approved'|'deprecated') => {
    try {
      await setStatus(name, version, status)
      await refresh()
    } catch (e:any) {
      alert(e.message || 'Failed to update status')
    }
  }

  const register = async (payload: UpsertPayload) => {
    await upsertGuardrail(payload)
    await refresh()
  }

  const toggleStatus = (s: string) => {
    setStatusFilters(prev => {
      const n = new Set(prev)
      if (n.has(s)) n.delete(s); else n.add(s)
      if (n.size===0) return new Set(['registered','approved','deprecated'])
      return n
    })
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="max-w-7xl mx-auto w-full px-4 py-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Catalog</h2>
          <RegisterDialog onSubmit={register} />
        </div>

        <Filters
          tag={tag}
          onTagChange={setTag}
          search={search}
          onSearch={setSearch}
          statuses={['registered','approved','deprecated']}
          activeStatuses={statusFilters}
          onToggleStatus={toggleStatus}
        />

        {loading && <div className="text-white/70">Loading…</div>}
        {error && <div className="text-amber-300">Error: {error}</div>}
        {!loading && !error && (
          <div className="grid-cards">
            {filtered.map(it => (
              <GuardrailCard key={it.id} item={it} onOpen={openDetail} onPromote={promote} />
            ))}
            {filtered.length === 0 && <div className="text-white/60">No items match your filters.</div>}
          </div>
        )}
      </main>

      <DetailDrawer open={open} onOpenChange={setOpen} data={active} />
    </div>
  )
}

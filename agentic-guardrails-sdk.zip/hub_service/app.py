
import uvicorn
from fastapi import FastAPI, Depends, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

from .models import GuardrailUpsert, GuardrailOut
from .db import init_indexes, upsert_guardrail, get_guardrail, list_versions, list_latest, set_status
from .auth import require_pat

app = FastAPI(title="Internal Guardrails Hub", version="1.0")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

@app.on_event("startup")
async def startup():
    await init_indexes()

@app.get("/healthz")
async def health():
    return {"ok": True}

@app.post("/api/guardrails", response_model=GuardrailOut)
async def register_guardrail(payload: GuardrailUpsert, _=Depends(require_pat)):
    doc = payload.model_dump()
    doc.setdefault("status", "registered")
    saved = await upsert_guardrail(doc)
    if not saved:
        raise HTTPException(500, "Failed to upsert")
    return GuardrailOut(id=str(saved["_id"]), **{k: v for k, v in saved.items() if k != "_id"})

@app.get("/api/guardrails/{name}/{version}", response_model=GuardrailOut)
async def get_specific(name: str, version: str):
    doc = await get_guardrail(name, version)
    if not doc: raise HTTPException(404, "Not found")
    return GuardrailOut(id=str(doc["_id"]), **{k: v for k, v in doc.items() if k != "_id"})

@app.get("/api/guardrails/{name}/versions")
async def versions(name: str):
    docs = await list_versions(name)
    return [{"id": str(d["_id"]), "name": d["name"], "version": d["version"],
             "status": d.get("status", "registered"), "updated_at": d.get("updated_at")} for d in docs]

@app.get("/api/guardrails")
async def list_latest_route(limit: int = Query(100, le=500), tag: str | None = None):
    docs = await list_latest(limit=limit, tag=tag)
    return [{"id": str(d["_id"]), "name": d["name"], "version": d["version"],
             "description": d.get("description"), "tags": d.get("tags", []),
             "status": d.get("status", "registered"), "updated_at": d.get("updated_at")} for d in docs]

@app.post("/api/guardrails/{name}/{version}/status")
async def promote(name: str, version: str, status: str, _=Depends(require_pat)):
    if status not in ("registered", "approved", "deprecated"):
        raise HTTPException(400, "Invalid status")
    doc = await set_status(name, version, status)
    if not doc: raise HTTPException(404, "Not found")
    return {"ok": True, "status": doc.get("status")}

if __name__ == "__main__":
    uvicorn.run("hub_service.app:app", host="0.0.0.0", port=8080, reload=False)

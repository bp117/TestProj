
import os, asyncio, time
from collections import defaultdict
from typing import Dict, List, Tuple, Any

import aioredis
from guardrails_sdk import GuardrailEngine, AgentConfig, ConsoleSink
from guardrails_sdk.adapters import trace_from_arize_like_spans
from guardrails_sdk.judge import StaticHeuristicJudge, OpenAIStyleJudge, GeminiJudge
from guardrails_sdk.sinks import MongoSink

NUM_WORKERS = int(os.getenv("NUM_WORKERS", "5"))
TRACE_EXPIRY_SEC = int(os.getenv("TRACE_EXPIRY_SEC", "60"))

def build_judge():
    provider = os.getenv("JUDGE_PROVIDER", "static").lower()
    if provider == "openai":
        return OpenAIStyleJudge(
            model=os.getenv("JUDGE_MODEL"),
            api_key=os.getenv("OPENAI_API_KEY") or os.getenv("AZURE_OPENAI_API_KEY"),
            base_url=os.getenv("OPENAI_BASE_URL"),
            org=os.getenv("OPENAI_ORG"),
            api_version=os.getenv("OPENAI_API_VERSION"),
        )
    if provider == "gemini":
        return GeminiJudge(model=os.getenv("GEMINI_MODEL"), provider=os.getenv("GEMINI_PROVIDER", "ai"))
    return StaticHeuristicJudge()

def build_sinks():
    sinks = []
    if os.getenv("MONGO_URI"):
        sinks.append(MongoSink())
    if os.getenv("CONSOLE_SINK_DISABLED", "false").lower() != "true":
        sinks.append(ConsoleSink())
    return sinks or [ConsoleSink()]

class TraceCollector:
    def __init__(self, engine: GuardrailEngine):
        self.engine = engine
        self.traces: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self.queue: asyncio.Queue[Tuple[str, List[Dict[str, Any]]]] = asyncio.Queue()
        self.trace_timestamps: Dict[str, float] = {}

    async def message_handler(self, message_json: Dict[str, Any]) -> None:
        trace_id = message_json.get("trace_id")
        message_type = message_json.get("name")
        now = time.time()
        if message_type == "TRACE_START":
            self.trace_timestamps[trace_id] = now; return
        if message_type == "TRACE_END":
            collected = self.traces.pop(trace_id, [])
            if collected: await self.queue.put((trace_id, collected))
            self.trace_timestamps.pop(trace_id, None); return
        self.traces[trace_id].append(message_json)
        self.trace_timestamps[trace_id] = now

    async def trace_processor(self, worker_id: int = 0) -> None:
        while True:
            trace_id, spans = await self.queue.get()
            try:
                trace = trace_from_arize_like_spans(spans)
                await self.engine.evaluate_trace(trace=trace, context={})
            except Exception as e:
                print(f"[Worker {worker_id}] Error processing {trace_id}: {e}")
            finally:
                self.queue.task_done()

    async def monitor_traces(self) -> None:
        while True:
            await asyncio.sleep(TRACE_EXPIRY_SEC)
            now = time.time()
            stale = [tid for tid, ts in self.trace_timestamps.items() if now - ts > TRACE_EXPIRY_SEC]
            for tid in stale:
                print(f"[Monitor] Removing stale trace: {tid}")
                self.traces.pop(tid, None)
                self.trace_timestamps.pop(tid, None)

async def main(config_path: str) -> None:
    cfg = AgentConfig.from_file(config_path)
    judge = build_judge()
    sinks = build_sinks()
    engine = GuardrailEngine(cfg=cfg, judge=judge, sinks=sinks)

    collector = TraceCollector(engine=engine)

    redis_host = os.getenv("REDIS_HOST", "localhost")
    redis_port = int(os.getenv("REDIS_PORT", "6379"))
    redis_password = os.getenv("REDIS_PASSWORD")
    redis_channel = os.getenv("REDIS_CHANNEL", "traces")

    redis_client = None
    try:
        redis_client = await aioredis.create_redis((redis_host, redis_port), password=redis_password, db=0)
        for i in range(NUM_WORKERS):
            asyncio.create_task(collector.trace_processor(worker_id=i))
        asyncio.create_task(collector.monitor_traces())

        channels = await redis_client.subscribe(redis_channel)
        ch = channels[0]
        print(f"Listening on Redis channel: {redis_channel} ...")
        while await ch.wait_message():
            raw_msg = await ch.get_json()
            await collector.message_handler(raw_msg)
        await asyncio.Event().wait()
    finally:
        if redis_client:
            redis_client.close()
            await redis_client.wait_closed()

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Usage: python -m runner.redis_trace_runner /path/to/agent-schema.json")
        raise SystemExit(2)
    asyncio.run(main(sys.argv[1]))

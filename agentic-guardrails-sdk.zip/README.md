
# Agentic Guardrails SDK + Internal Hub

## Contents
- `guardrails_sdk/` - SDK package (OOTB rails: goal drift, step budgeting, tool misuse, loop detection)
- `runner/redis_trace_runner.py` - realtime evaluator wired to Redis
- `hub_service/` - FastAPI-based internal Guardrails Hub (register & discover guardrails)
- `examples/run_local_file.py` - local test runner for a JSON trace file

## Quickstart (SDK + Runner)
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Env for Redis
export REDIS_HOST=localhost
export REDIS_PORT=6379
export REDIS_CHANNEL=traces

# Judge: use Gemini (AI Studio) or Vertex
export JUDGE_PROVIDER=gemini
export GEMINI_PROVIDER=ai
export GEMINI_MODEL=gemini-1.5-pro
export GOOGLE_API_KEY=YOUR_KEY

# OR OpenAI-compatible
# export JUDGE_PROVIDER=openai
# export OPENAI_API_KEY=sk-...
# export JUDGE_MODEL=gpt-4o-mini

# Mongo sink (optional but recommended)
export MONGO_URI="mongodb://localhost:27017"
export MONGO_DB=guardrails
export MONGO_COLLECTION=reports

# Internal hub (optional)
export INTERNAL_GUARDRAILS_HUB_ENABLED=true
export INTERNAL_GUARDRAILS_HUB_URL="http://localhost:8080/api/guardrails"
export INTERNAL_GUARDRAILS_HUB_TOKEN="dev-pat-123"

# Run the evaluator
python -m runner.redis_trace_runner /path/to/agent-schema.json
```

## Hub Service
```bash
cd hub_service
pip install -r requirements.txt
export MONGO_URI="mongodb://localhost:27017"
export HUB_PATS="dev-pat-123"
python -m hub_service.app
# Open http://localhost:8080/docs
```

## Example (offline test with files)
```bash
cp /mnt/data/agent-schema.json examples/agent-schema.json  # supply your config
cp /mnt/data/trace.json examples/trace.json                # supply your trace
python examples/run_local_file.py
```

## Registering Custom Guardrails
```python
from guardrails_sdk.registry import guardrail
from guardrails_sdk.guardrails.base import BaseGuardrail
from guardrails_sdk.models import GuardrailResult

@guardrail("pii_redaction", version="1.0", description="Detects PII leakage in tool IO")
class PIIRedactionGuardrail(BaseGuardrail):
    async def evaluate(self, *, trace, goal_name, context) -> GuardrailResult:
        return GuardrailResult(self.name, goal_name, passed=True, severity="info")
```
When this module imports, metadata is POSTed to your internal hub if `INTERNAL_GUARDRAILS_HUB_ENABLED=true`.

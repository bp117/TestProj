
from __future__ import annotations
from typing import Protocol, Any, Dict, Optional
import os, datetime, asyncio

class Sink(Protocol):
    async def write(self, record: Dict[str, Any]) -> None: ...

class NullSink:
    async def write(self, record: Dict[str, Any]) -> None:
        return

class ConsoleSink:
    async def write(self, record: Dict[str, Any]) -> None:
        from pprint import pprint
        pprint(record)

class MongoSink:
    def __init__(self, uri: Optional[str] = None, db: Optional[str] = None, collection: Optional[str] = None):
        self.uri = uri or os.getenv("MONGO_URI")
        self.db_name = db or os.getenv("MONGO_DB", "guardrails")
        self.coll_name = collection or os.getenv("MONGO_COLLECTION", "reports")
        if not self.uri: raise RuntimeError("MongoSink: MONGO_URI is required")
        self._motor = None; self._pymongo = None; self._coll = None; self._lock = asyncio.Lock()

    async def _ensure(self):
        if self._coll: return
        async with self._lock:
            if self._coll: return
            try:
                import motor.motor_asyncio as motor
                self._motor = motor.AsyncIOMotorClient(self.uri)
                self._coll = self._motor[self.db_name][self.coll_name]
                await self._coll.create_index([("trace_id", 1), ("goal_name", 1)], background=True)
            except Exception:
                import pymongo
                from concurrent.futures import ThreadPoolExecutor
                self._executor = ThreadPoolExecutor(max_workers=2)
                self._pymongo = pymongo.MongoClient(self.uri)
                self._coll = self._pymongo[self.db_name][self.coll_name]
                self._coll.create_index([("trace_id", 1), ("goal_name", 1)], background=True)

    async def write(self, record: Dict[str, Any]) -> None:
        await self._ensure()
        doc = dict(record); doc["inserted_at"] = datetime.datetime.utcnow()
        if self._motor:
            await self._coll.update_one({"trace_id": doc.get("trace_id"), "goal_name": doc.get("goal_name")},
                                        {"$set": doc}, upsert=True)
        else:
            loop = asyncio.get_running_loop()
            await loop.run_in_executor(getattr(self, "_executor"),
                lambda: self._coll.update_one({"trace_id": doc.get("trace_id"), "goal_name": doc.get("goal_name")},
                                              {"$set": doc}, upsert=True))


from __future__ import annotations
import json
from typing import Any, Dict, List, Optional
from .models import Trace, TraceEvent, EventKind

def _safe_json_loads(s: Optional[str]) -> Optional[Any]:
    if not s:
        return None
    try:
        return json.loads(s)
    except Exception:
        return None

def trace_from_arize_like_spans(spans: List[Dict[str, Any]]) -> Trace:
    if not spans:
        raise ValueError("Empty spans list")

    trace_id = spans[0].get("trace_id", "unknown")
    events: List[TraceEvent] = []

    for s in spans:
        attrs = s.get("attributes", {}) or {}
        kind_str = attrs.get("openinference.span.kind", "").upper()
        if "LLM" in kind_str:
            kind = EventKind.LLM
        elif "TOOL" in kind_str:
            kind = EventKind.TOOL
        else:
            kind = EventKind.OTHER

        token_count = attrs.get("llm.token_count.total")
        input_value = attrs.get("input.value")
        output_value = attrs.get("output.value")

        tool_name = None
        tool_args = None
        if kind == EventKind.TOOL:
            tool_name = s.get("name")
            try:
                tool_args = json.loads(input_value) if isinstance(input_value, str) else input_value
            except Exception:
                tool_args = None
        else:
            tools_list = _safe_json_loads(attrs.get("llm.tools"))
            if isinstance(tools_list, list) and tools_list:
                f = tools_list[0].get("function") if isinstance(tools_list[0], dict) else None
                if isinstance(f, dict):
                    tool_name = f.get("name")
                    tool_args = f.get("parameters")

        def to_int_or_none(v):
            try:
                return int(v)
            except Exception:
                return None

        events.append(
            TraceEvent(
                name=s.get("name") or tool_name or "unknown",
                trace_id=s.get("trace_id", trace_id),
                span_id=s.get("span_id", "unknown"),
                kind=kind,
                input_value=input_value,
                output_value=output_value,
                tool_name=tool_name,
                tool_args=tool_args,
                token_count=token_count if isinstance(token_count, int) else None,
                start_time_ns=to_int_or_none(s.get("start_time")),
                end_time_ns=to_int_or_none(s.get("end_time")),
            )
        )

    return Trace(trace_id=trace_id, events=events)

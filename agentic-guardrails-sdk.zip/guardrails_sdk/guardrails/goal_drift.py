
from __future__ import annotations
import re
from typing import Dict, Any, List
from .base import BaseGuardrail
from ..models import GuardrailResult, Violation, Trace, EventKind
from ..config import AgentConfig, GoalDriftGoal
from ..judge import LLMJudge

def _build_plan_from_trace(trace: Trace) -> str:
    lines: List[str] = []
    for e in trace.events:
        if e.kind == EventKind.LLM and e.tool_name:
            lines.append(f"- LLM called tool: {e.tool_name}")
        elif e.kind == EventKind.TOOL:
            lines.append(f"- TOOL executed: {e.name}")
    return "\n".join(lines) if lines else "- (no plan extracted)"

def _tools_def_from_config(cfg: AgentConfig, goal: GoalDriftGoal) -> str:
    return f"- Expected primary tool: {goal.trajectory.tool_name}\n- Expected params: {', '.join(goal.trajectory.expected_params.keys()) or '(none)'}"

class GoalDriftGuardrail(BaseGuardrail):
    def __init__(self, name: str, cfg: AgentConfig, judge: LLMJudge):
        super().__init__(name); self.cfg = cfg; self.judge = judge

    async def evaluate(self, *, trace: Trace, goal_name: str, context: Dict[str, Any]) -> GuardrailResult:
        gd_goal: GoalDriftGoal | None = self.cfg.goal_drift_for(goal_name)
        violations: List[Violation] = []; metrics: Dict[str, Any] = {}
        if not self.cfg.goal_drift.enabled or gd_goal is None:
            return GuardrailResult(self.name, goal_name, True, "info", violations, metrics)

        expected_tool = gd_goal.trajectory.tool_name
        used_tools = trace.used_tools()
        if expected_tool and expected_tool not in used_tools:
            violations.append(Violation("GD.MISSING_TOOL", f"Expected tool '{expected_tool}' not used",
                                        [e.span_id for e in trace.events if e.kind in (EventKind.LLM, EventKind.TOOL)]))

        for e in trace.events:
            if (e.kind == EventKind.TOOL and (e.name == expected_tool or e.tool_name == expected_tool)) and e.tool_args:
                for p_name, rule in gd_goal.trajectory.expected_params.items():
                    if rule.required and p_name not in e.tool_args:
                        violations.append(Violation("GD.MISSING_PARAM", f"Missing required param '{p_name}'", [e.span_id]))
                    if rule.enum and p_name in e.tool_args and e.tool_args[p_name] not in set(rule.enum):
                        violations.append(Violation("GD.BAD_ENUM", f"Param '{p_name}' not in {rule.enum}", [e.span_id]))
                    if rule.pattern and p_name in e.tool_args and not re.search(rule.pattern, str(e.tool_args[p_name])):
                        violations.append(Violation("GD.BAD_PATTERN", f"Param '{p_name}' fails pattern {rule.pattern}", [e.span_id]))

        task = context.get("task") or "Execute the user request using available tools."
        plan = _build_plan_from_trace(trace)
        tools_def = _tools_def_from_config(self.cfg, gd_goal)
        label = await self.judge.classify_plan(task, tools_def, plan)
        metrics["judge_label"] = label
        if label == "invalid":
            violations.append(Violation("GD.JUDGE_INVALID", "LLM Judge marked the plan INVALID", []))

        passed = (len(violations) == 0) and (label in ("ideal", "valid"))
        severity = "fail" if not passed else "info"
        return GuardrailResult(self.name, goal_name, passed, severity, violations, metrics)

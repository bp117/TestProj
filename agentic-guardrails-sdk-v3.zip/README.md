
# Agentic Guardrails SDK (v2)

**Goal Drift = Trajectory Accuracy + Tool Selection**

- Trajectory: Arize-style `llm_classify` prompt with golden trajectories; model returns `correct`/`incorrect`.
- Tool Selection: expected primary tool + param validation (required/enum/pattern) + allow/deny policy per goal if configured.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Redis channel (all pods publish to same runtime id)
export REDIS_HOST=localhost
export REDIS_PORT=6379
export REDIS_CHANNEL=my_agent_runtime_id

# Judge: Gemini (AI Studio or Vertex)
export JUDGE_PROVIDER=gemini
export GEMINI_PROVIDER=ai
export GEMINI_MODEL=gemini-1.5-pro
export GOOGLE_API_KEY=YOUR_KEY
# or OpenAI-compatible:
# export JUDGE_PROVIDER=openai
# export OPENAI_API_KEY=sk-...
# export JUDGE_MODEL=gpt-4o-mini

# Optional golden trajectories
export GOLDEN_TRAJECTORIES_JSON='[{"user_question":"To calculate the value of an expression","trajectory":{"1":"calculate"}},{"user_question":"To calculate the weather of a city","trajectory":{"1":"get_weather"}}]'

# Mongo sink
export MONGO_URI="mongodb://localhost:27017"
export MONGO_DB=guardrails
export MONGO_COLLECTION=reports

python -m runner.redis_trace_runner /path/to/agent-schema.json
```


### Using Arize Phoenix built-in `llm_classify`
To force the SDK to call **phoenix.evals.llm_classify** (as in your notebook):
```bash
pip install arize-phoenix-evals
export USE_PHOENIX_CLASSIFIER=true
export OPENAI_API_KEY=sk-...      # Phoenix OpenAIModel (gpt-4o-mini by default)
# optional: override
export JUDGE_MODEL=gpt-4o-mini
```
When `USE_PHOENIX_CLASSIFIER=false` (default) or Phoenix isn’t installed, the SDK falls back to the internal Gemini-based classifier for trajectory accuracy.

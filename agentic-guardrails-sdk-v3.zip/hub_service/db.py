
import os
import motor.motor_asyncio
from typing import Any, Dict
from datetime import datetime

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB  = os.getenv("MONGO_DB", "guardrails_hub")

_client = motor.motor_asyncio.AsyncIOMotorClient(MONGO_URI)
_db = _client[MONGO_DB]
coll = _db["guardrails"]

async def init_indexes():
    await coll.create_index([("name", 1), ("version", 1)], unique=True, background=True)
    await coll.create_index([("name", 1), ("updated_at", -1)], background=True)

async def upsert_guardrail(doc: Dict[str, Any]) -> Dict[str, Any]:
    q = {"name": doc["name"], "version": doc["version"]}
    doc["updated_at"] = datetime.utcnow()
    doc.setdefault("created_at", doc["updated_at"])
    await coll.update_one(q, {"$setOnInsert": {"created_at": doc["created_at"]}, "$set": doc}, upsert=True)
    return await coll.find_one(q)

async def get_guardrail(name: str, version: str) -> Dict[str, Any] | None:
    return await coll.find_one({"name": name, "version": version})

async def list_versions(name: str) -> list[Dict[str, Any]]:
    cur = coll.find({"name": name}).sort("updated_at", -1)
    return [doc async for doc in cur]

async def list_latest(limit: int = 100, tag: str | None = None) -> list[Dict[str, Any]]:
    pipeline = [{"$sort": {"name": 1, "updated_at": -1}},
                {"$group": {"_id": "$name", "doc": {"$first": "$$ROOT"}}},
                {"$replaceRoot": {"newRoot": "$doc"}},
                {"$limit": limit}]
    if tag:
        pipeline.insert(0, {"$match": {"tags": tag}})
    cur = coll.aggregate(pipeline)
    return [doc async for doc in cur]

async def set_status(name: str, version: str, status: str) -> Dict[str, Any] | None:
    await coll.update_one({"name": name, "version": version}, {"$set": {"status": status, "updated_at": datetime.utcnow()}})
    return await get_guardrail(name, version)


from __future__ import annotations
from typing import Dict, Any, List
import os, re, httpx, json

def _choose_provider() -> str:
    return os.getenv("JUDGE_PROVIDER", "gemini").lower()

def _normalize_to_rails(text: str, rails: List[str]) -> str:
    t = (text or "").strip().lower()
    for r in rails:
        if re.search(rf"\b{re.escape(r.lower())}\b", t):
            return r
    return "incorrect" if any(r.lower() == "incorrect" for r in rails) else rails[0]

async def llm_classify_one(*, template: str, variables: Dict[str, Any], rails: List[str]) -> str:
    """Render template and classify into `rails` with the configured LLM provider."""
    prompt = template.format(**variables)
    provider = _choose_provider()

    if provider == "openai":
        base = os.getenv("OPENAI_BASE_URL", "https://api.openai.com").rstrip("/")
        url = f"{base}/v1/chat/completions"
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise RuntimeError("OPENAI_API_KEY required for JUDGE_PROVIDER=openai")
        headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
        payload = {
            "model": os.getenv("JUDGE_MODEL", "gpt-4o-mini"),
            "messages": [
                {"role": "system", "content": f"Respond with one word only: {', '.join(rails)}."},
                {"role": "user", "content": prompt},
            ],
            "temperature": 0,
            "max_tokens": 8,
        }
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.post(url, headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        return _normalize_to_rails(text, rails)

    # default Gemini
    model = os.getenv("GEMINI_MODEL", "gemini-1.5-pro")
    gprov = os.getenv("GEMINI_PROVIDER", "ai").lower()
    payload = {
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0, "maxOutputTokens": 8},
    }

    if gprov == "ai":
        key = os.getenv("GOOGLE_API_KEY")
        if not key:
            raise RuntimeError("GOOGLE_API_KEY required for GEMINI_PROVIDER=ai")
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}"
        async with httpx.AsyncClient(timeout=15.0) as client:
            r = await client.post(url, json=payload)
            r.raise_for_status()
            data = r.json()
            parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts)
        return _normalize_to_rails(text, rails)

    # Vertex
    import google.auth, google.auth.transport.requests
    creds, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
    google.auth.transport.requests.Request().refresh(creds)
    token = creds.token
    project = os.getenv("VERTEX_PROJECT")
    location = os.getenv("VERTEX_LOCATION")
    if not (project and location):
        raise RuntimeError("VERTEX_PROJECT and VERTEX_LOCATION required for GEMINI_PROVIDER=vertex")
    url = f"https://{location}-aiplatform.googleapis.com/v1/projects/{project}/locations/{location}/publishers/google/models/{model}:generateContent"
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    async with httpx.AsyncClient(timeout=15.0) as client:
        r = await client.post(url, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
        parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
        text = "".join(p.get("text", "") for p in parts)
    return _normalize_to_rails(text, rails)

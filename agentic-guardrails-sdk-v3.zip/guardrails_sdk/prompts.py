
"""Prompt templates compatible with Arize-style trajectory accuracy checks."""

TRAJECTORY_ACCURACY_PROMPT_WITH_REFERENCE = """
You are a helpful AI bot that checks whether an AI agent's internal trajectory is accurate and effective.

You will be given:
1. The agent's actual trajectory of tool calls
2. You will be given input data from a user that the agent used to make a decision
3. You will be given a tool call definition, what the agent used to make the tool call
4. You will be given a golden trajectory for various input questions that represents the ideal flows in normal use for given question

An accurate trajectory:
- Progresses logically from step to step
- Follows the golden trajectory where reasonable
- Shows a clear path toward completing a goal
- Is reasonably efficient (doesn't take unnecessary detours)

##

Golden Trajectory info:
{reference_outputs}

##

Actual Trajectory:
{tool_calls}

User Inputs:
{attributes.input.value}

Tool Definition:
{attributes.llm.tools}

##

- First identify the correct trajectory based on user's input 
- Compare the actual trajectory to the golden one: 
    - Highlight any major deviations
    - Determine whether the deviations are acceptable or harmful
    - Assess if the overall goal is still achieved effectively

Your response must be a single string, either `correct` or `incorrect`, and must not include any additional text.

- Respond with `correct` if the agent's trajectory adheres to the rubric and accomplishes the task effectively.
- Respond with `incorrect` if the trajectory is confusing, misaligned with the goal, inefficient, or does not accomplish the task.
"""

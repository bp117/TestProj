
from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Dict, Any, Literal, Optional
import os, re, json

JudgeLabel = Literal["ideal", "valid", "invalid"]

class LLMJudge(ABC):
    @abstractmethod
    async def classify_plan(self, task: str, tools_def: str, plan: str) -> JudgeLabel: ...

class StaticHeuristicJudge(LLMJudge):
    def __init__(self, allowed_tools: set[str] | None = None):
        self.allowed_tools = allowed_tools or set()

    async def classify_plan(self, task: str, tools_def: str, plan: str) -> JudgeLabel:
        steps = [ln for ln in plan.splitlines() if ln.strip().startswith("- ")]
        used = {ln.split(":", 1)[-1].strip() for ln in steps if ":" in ln}
        if used and not used.issubset(self.allowed_tools):
            return "invalid"
        return "ideal" if len(steps) <= 3 else "valid"

class OpenAIStyleJudge(LLMJudge):
    def __init__(self, model: Optional[str] = None, api_key: Optional[str] = None,
                 base_url: Optional[str] = None, org: Optional[str] = None,
                 api_version: Optional[str] = None, timeout: float = 15.0):
        self.model = model or os.getenv("JUDGE_MODEL", "gpt-4o-mini")
        self.api_key = api_key or os.getenv("OPENAI_API_KEY") or os.getenv("AZURE_OPENAI_API_KEY")
        self.base_url = base_url or os.getenv("OPENAI_BASE_URL", "https://api.openai.com")
        self.org = org or os.getenv("OPENAI_ORG")
        self.api_version = api_version or os.getenv("OPENAI_API_VERSION")
        self.timeout = timeout
        if not self.api_key:
            raise RuntimeError("OpenAIStyleJudge: missing OPENAI_API_KEY/AZURE_OPENAI_API_KEY")
        if not self.model:
            raise RuntimeError("OpenAIStyleJudge: missing JUDGE_MODEL")

    def _endpoint(self) -> str:
        base = self.base_url.rstrip("/")
        url = f"{base}/v1/chat/completions"
        if self.api_version and "azure" in base.lower():
            url = f"{url}?api-version={self.api_version}"
        return url

    @staticmethod
    def _format_prompt(task: str, tools_def: str, plan: str) -> list[dict]:
        system = ("You are an evaluation assistant. Return exactly one word: ideal, valid, or invalid.")
        user = (f"DATA\n[User task]: {task}\n[Tools]:\n{tools_def}\n[Plan]:\n{plan}\n"
                "Criteria: valid tools, sufficient tools, success likelihood, shortest efficient plan. "
                "Answer with one word only.")
        return [{"role": "system", "content": system}, {"role": "user", "content": user}]

    @staticmethod
    def _normalize(label: str) -> JudgeLabel:
        m = re.search(r"(ideal|valid|invalid)", (label or "").strip().lower())
        return m.group(1) if m else "valid"

    async def classify_plan(self, task: str, tools_def: str, plan: str) -> JudgeLabel:
        import httpx
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        if self.org: headers["OpenAI-Organization"] = self.org
        messages = self._format_prompt(task, tools_def, plan)
        payload = {"model": self.model, "messages": messages, "temperature": 0, "max_tokens": 5}
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(self._endpoint(), headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        return self._normalize(text)

# -------- Gemini Judge --------
def _normalize_gemini_label(text: str) -> JudgeLabel:
    m = re.search(r"\b(ideal|valid|invalid)\b", (text or "").strip().lower())
    return m.group(1) if m else "valid"

class GeminiJudge(LLMJudge):
    def __init__(self, model: Optional[str] = None, provider: Optional[str] = None, timeout: float = 12.0):
        self.model = model or os.getenv("GEMINI_MODEL", "gemini-1.5-pro")
        self.provider = (provider or os.getenv("GEMINI_PROVIDER", "ai")).lower()
        self.timeout = timeout
        if self.provider not in ("ai", "vertex"):
            raise RuntimeError("GeminiJudge: GEMINI_PROVIDER must be 'ai' or 'vertex'")
        if self.provider == "ai" and not os.getenv("GOOGLE_API_KEY"):
            raise RuntimeError("GeminiJudge(AI Studio): missing GOOGLE_API_KEY")
        if self.provider == "vertex":
            if not os.getenv("VERTEX_PROJECT") or not os.getenv("VERTEX_LOCATION"):
                raise RuntimeError("GeminiJudge(Vertex): VERTEX_PROJECT and VERTEX_LOCATION are required")

    @staticmethod
    def _format_payload(task: str, tools_def: str, plan: str) -> dict:
        user = (
            "You are an evaluation assistant. Evaluate the agent's plan and return exactly one word: "
            "'ideal', 'valid', or 'invalid'. Use lowercase ONLY.\n\n"
            f"[User task]\n{task}\n\n[Tools]\n{tools_def}\n\n[Plan]\n{plan}\n\n"
            "Criteria: valid/applicable tools, sufficiency, success likelihood, shortest efficient plan.\n"
            "Output: one word only."
        )
        return {
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {"temperature": 0, "maxOutputTokens": 10}
        }

    async def _call_ai(self, payload: dict) -> str:
        import httpx
        base = "https://generativelanguage.googleapis.com/v1beta"
        url = f"{base}/models/{self.model}:generateContent?key={os.getenv('GOOGLE_API_KEY')}"
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(url, json=payload)
            r.raise_for_status()
            data = r.json()
            parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts)
            return _normalize_gemini_label(text)

    async def _call_vertex(self, payload: dict) -> str:
        import httpx, google.auth, google.auth.transport.requests
        creds, _ = google.auth.default(scopes=["https://www.googleapis.com/auth/cloud-platform"])
        auth_req = google.auth.transport.requests.Request()
        creds.refresh(auth_req)
        token = creds.token
        project = os.getenv("VERTEX_PROJECT")
        location = os.getenv("VERTEX_LOCATION")
        base = f"https://{location}-aiplatform.googleapis.com/v1"
        url = f"{base}/projects/{project}/locations/{location}/publishers/google/models/{self.model}:generateContent"
        headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        async with httpx.AsyncClient(timeout=self.timeout) as client:
            r = await client.post(url, headers=headers, json=payload)
            r.raise_for_status()
            data = r.json()
            parts = data.get("candidates", [{}])[0].get("content", {}).get("parts", [])
            text = "".join(p.get("text", "") for p in parts)
            return _normalize_gemini_label(text)

    async def classify_plan(self, task: str, tools_def: str, plan: str) -> JudgeLabel:
        payload = self._format_payload(task, tools_def, plan)
        if self.provider == "ai":
            return await self._call_ai(payload)
        return await self._call_vertex(payload)

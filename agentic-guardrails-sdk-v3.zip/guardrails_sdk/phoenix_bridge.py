
from __future__ import annotations
from typing import Any, Dict, Optional
import os, re

# Soft dependency: arize-phoenix-evals
def _maybe_import_phoenix():
    try:
        from phoenix.evals import llm_classify, OpenAIModel  # type: ignore
        return llm_classify, OpenAIModel
    except Exception as e:
        raise RuntimeError(
            "phoenix.evals not available. Install with: pip install arize-phoenix-evals"
        ) from e

def _normalize_ci(text: str) -> str:
    t = (text or "").strip().lower()
    return "correct" if re.search(r"\bcorrect\b", t) else "incorrect"

async def phoenix_llm_classify_single(*, template: str, variables: Dict[str, Any]) -> str:
    """Use arize-phoenix-evals `llm_classify` on a single example.

    Requirements:
      - OPENAI_API_KEY set (for phoenix OpenAIModel)
      - arize-phoenix-evals installed

    NOTE: Phoenix currently expects a dataframe. We create a 1-row DF with the
    same column names as your notebook code: tool_calls, attributes.llm.tools,
    attributes.input.value, and reference_outputs.
    """
    import pandas as pd
    llm_classify, OpenAIModel = _maybe_import_phoenix()
    df = pd.DataFrame([{
        "tool_calls": variables.get("tool_calls"),
        "attributes.llm.tools": variables.get("attributes.llm.tools"),
        "attributes.input.value": variables.get("attributes.input.value"),
        "reference_outputs": variables.get("reference_outputs"),
    }])

    model = OpenAIModel(
        api_key=os.environ.get("OPENAI_API_KEY"),
        model=os.environ.get("JUDGE_MODEL", "gpt-4o-mini"),
        temperature=0.0,
    )

    rails = ["correct", "incorrect"]
    res = llm_classify(
        dataframe=df,
        template=template,
        model=model,
        rails=rails,
        include_prompt=False,
        provide_explanation=False,
        verbose=False,
        concurrency=5,
    )

    # Phoenix returns a dataframe; try to read a 'label' or 'value' column,
    # otherwise parse the first textual field for 'correct/incorrect'.
    if "label" in res.columns:
        return _normalize_ci(str(res["label"].iloc[0]))
    for c in ("value","classification","prediction","output","response"):
        if c in res.columns:
            return _normalize_ci(str(res[c].iloc[0]))
    # last resort: scan all non-null fields
    for c in res.columns:
        v = str(res[c].iloc[0])
        if v: return _normalize_ci(v)
    return "incorrect"


from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional
import time

class EventKind(str, Enum):
    LLM = "LLM"
    TOOL = "TOOL"
    OTHER = "OTHER"

@dataclass
class TraceEvent:
    name: str
    trace_id: str
    span_id: str
    kind: EventKind
    input_value: Optional[str] = None
    output_value: Optional[str] = None
    tool_name: Optional[str] = None
    tool_args: Optional[Dict[str, Any]] = None
    token_count: Optional[int] = None
    start_time_ns: Optional[int] = None
    end_time_ns: Optional[int] = None

@dataclass
class Trace:
    trace_id: str
    events: List[TraceEvent] = field(default_factory=list)
    created_at: float = field(default_factory=lambda: time.time())

    def steps(self) -> int:
        return sum(1 for e in self.events if e.kind in (EventKind.LLM, EventKind.TOOL))

    def total_tokens(self) -> int:
        return sum((e.token_count or 0) for e in self.events if e.kind == EventKind.LLM)

    def duration_seconds(self) -> float:
        starts = [e.start_time_ns for e in self.events if e.start_time_ns]
        ends   = [e.end_time_ns for e in self.events if e.end_time_ns]
        if not starts or not ends:
            return 0.0
        return max(ends) / 1e9 - min(starts) / 1e9

    def used_tools(self) -> List[str]:
        out = []
        for e in self.events:
            if e.kind == EventKind.TOOL and e.name:
                out.append(e.name)
            elif e.tool_name:
                out.append(e.tool_name)
        return out

@dataclass
class Violation:
    code: str
    message: str
    span_ids: List[str] = field(default_factory=list)
    extras: Dict[str, Any] = field(default_factory=dict)

@dataclass
class GuardrailResult:
    name: str
    goal_name: str
    passed: bool
    severity: str
    violations: List[Violation] = field(default_factory=list)
    metrics: Dict[str, Any] = field(default_factory=dict)

@dataclass
class GuardrailReport:
    trace_id: str
    goal_name: str
    results: List[GuardrailResult]
    overall_passed: bool

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trace_id": self.trace_id,
            "goal_name": self.goal_name,
            "overall_passed": self.overall_passed,
            "results": [asdict(r) for r in self.results],
        }

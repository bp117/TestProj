
from __future__ import annotations
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Any

@dataclass
class BudgetGoal:
    goal_name: str
    max_duration_seconds: Optional[int] = None
    max_token_limit: Optional[int] = None
    max_steps: Optional[int] = None

@dataclass
class Budgeting:
    enabled: bool = False
    goals: List[BudgetGoal] = field(default_factory=list)

@dataclass
class LoopGoal:
    goal_name: str
    threshold: int = 3

@dataclass
class LoopDetection:
    enabled: bool = False
    goals: List[LoopGoal] = field(default_factory=list)

@dataclass
class SafeToolsGoal:
    goal_name: str
    allow: List[str] = field(default_factory=list)
    deny: List[str] = field(default_factory=list)

@dataclass
class SafeTools:
    enabled: bool = False
    goals: List[SafeToolsGoal] = field(default_factory=list)

@dataclass
class ExpectedParamRule:
    required: bool = False
    enum: Optional[List[str]] = None
    pattern: Optional[str] = None

@dataclass
class Trajectory:
    tool_name: str
    expected_params: Dict[str, ExpectedParamRule] = field(default_factory=dict)

@dataclass
class GoalDriftGoal:
    goal_name: str
    reasoning: Optional[str]
    trajectory: Trajectory

@dataclass
class GoalDrift:
    enabled: bool = False
    goals: List[GoalDriftGoal] = field(default_factory=list)

@dataclass
class ModelsCfg:
    router_model: Optional[str] = None
    judge_model: Optional[str] = None

@dataclass
class AgentConfig:
    budgeting: Budgeting = field(default_factory=Budgeting)
    loop_detection: LoopDetection = field(default_factory=LoopDetection)
    safe_tools: SafeTools = field(default_factory=SafeTools)
    goal_drift: GoalDrift = field(default_factory=GoalDrift)
    models: ModelsCfg = field(default_factory=ModelsCfg)

    _budget_by_goal: Dict[str, BudgetGoal] = field(default_factory=dict, init=False)
    _loop_by_goal: Dict[str, LoopGoal] = field(default_factory=dict, init=False)
    _safe_tools_by_goal: Dict[str, SafeToolsGoal] = field(default_factory=dict, init=False)
    _gd_by_goal: Dict[str, GoalDriftGoal] = field(default_factory=dict, init=False)

    @classmethod
    def from_file(cls, p: str | Path) -> "AgentConfig":
        data = json.loads(Path(p).read_text())
        return cls.from_dict(data)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "AgentConfig":
        cfg = cls()
        cfg.models = ModelsCfg(**d.get("models", {}))

        b = d.get("guardrails", {}).get("budgeting", {})
        cfg.budgeting.enabled = bool(b.get("enabled", False))
        cfg.budgeting.goals = [BudgetGoal(**g) for g in b.get("goals", [])]
        cfg._budget_by_goal = {g.goal_name: g for g in cfg.budgeting.goals}

        l = d.get("loop_detection", {})
        cfg.loop_detection.enabled = bool(l.get("enabled", False))
        cfg.loop_detection.goals = [LoopGoal(**g) for g in l.get("goals", [])]
        cfg._loop_by_goal = {g.goal_name: g for g in cfg.loop_detection.goals}

        s = d.get("safe_tools", {})
        cfg.safe_tools.enabled = bool(s.get("enabled", False))
        cfg.safe_tools.goals = [SafeToolsGoal(**g) for g in s.get("goals", [])]
        cfg._safe_tools_by_goal = {g.goal_name: g for g in cfg.safe_tools.goals}

        gd = d.get("goal_drift", {})
        cfg.goal_drift.enabled = bool(gd.get("enabled", False))
        gd_goals = []
        for g in gd.get("goals", []):
            traj_raw = g.get("trajectory", {})
            exp_params = {
                k: ExpectedParamRule(
                    required=bool(v.get("required", False)),
                    enum=v.get("enum"),
                    pattern=v.get("pattern"),
                )
                for k, v in traj_raw.get("expected_params", {}).items()
            }
            traj = Trajectory(tool_name=traj_raw.get("tool_name", ""), expected_params=exp_params)
            gd_goals.append(
                GoalDriftGoal(
                    goal_name=g.get("goal_name"),
                    reasoning=g.get("reasoning"),
                    trajectory=traj
                )
            )
        cfg.goal_drift.goals = gd_goals
        cfg._gd_by_goal = {g.goal_name: g for g in cfg.goal_drift.goals}
        return cfg

    def budget_for(self, goal: str) -> Optional[BudgetGoal]:
        return self._budget_by_goal.get(goal)

    def loop_for(self, goal: str) -> Optional[LoopGoal]:
        return self._loop_by_goal.get(goal)

    def safe_tools_for(self, goal: str) -> Optional[SafeToolsGoal]:
        return self._safe_tools_by_goal.get(goal)

    def goal_drift_for(self, goal: str) -> Optional[GoalDriftGoal]:
        return self._gd_by_goal.get(goal)


from __future__ import annotations
from typing import Dict, Any, List, Optional
from .models import Trace, GuardrailReport, GuardrailResult
from .config import AgentConfig
from .registry import GuardrailRegistry
from .guardrails import GoalDriftGuardrail, StepBudgetingGuardrail, ToolMisuseGuardrail, LoopDetectionGuardrail
from .judge import LLMJudge, StaticHeuristicJudge
from .sinks import Sink, NullSink

class GuardrailEngine:
    def __init__(self, cfg: AgentConfig, judge: Optional[LLMJudge] = None,
                 sinks: Optional[List[Sink]] = None, rails: Optional[List[str]] = None):
        self.cfg = cfg
        self.judge = judge or StaticHeuristicJudge()
        self.sinks = sinks or [NullSink()]
        self.rails = rails
        GuardrailRegistry.register("goal_drift", GoalDriftGuardrail)
        GuardrailRegistry.register("step_budgeting", StepBudgetingGuardrail)
        GuardrailRegistry.register("tool_misuse", ToolMisuseGuardrail)
        GuardrailRegistry.register("loop_detection", LoopDetectionGuardrail)

    def _infer_goal(self, trace: Trace) -> str:
        used = set(trace.used_tools())
        for g in self.cfg.goal_drift.goals or []:
            if g.trajectory.tool_name and g.trajectory.tool_name in used:
                return g.goal_name
        if self.cfg.budgeting.goals:
            return self.cfg.budgeting.goals[0].goal_name
        return "default"

    async def evaluate_trace(self, trace: Trace, goal_name: Optional[str] = None,
                             context: Optional[Dict[str, Any]] = None) -> GuardrailReport:
        goal_name = goal_name or self._infer_goal(trace)
        context = context or {}
        to_run = self.rails or ["goal_drift", "step_budgeting", "tool_misuse", "loop_detection"]
        instances = []
        for rname in to_run:
            cls = GuardrailRegistry.get(rname)
            if not cls: continue
            if rname == "goal_drift":
                instances.append(cls(rname, self.cfg, self.judge))
            else:
                instances.append(cls(rname, self.cfg))

        results: List[GuardrailResult] = []
        for rail in instances:
            res = await rail.evaluate(trace=trace, goal_name=goal_name, context=context)
            results.append(res)

        overall = all(r.passed for r in results)
        report = GuardrailReport(trace_id=trace.trace_id, goal_name=goal_name, results=results, overall_passed=overall)
        for s in self.sinks:
            try: await s.write(report.to_dict())
            except Exception: pass
        return report
